const canvas = document.getElementById("gameCanvas");
const ctx = canvas.getContext("2d");

// Make canvas full screen
function resizeCanvas() {
  canvas.width = window.innerWidth;
  canvas.height = window.innerHeight;
}
window.addEventListener("resize", resizeCanvas);
resizeCanvas();

let score = 0;
let health = 100;

const aircraftImg = new Image();
aircraftImg.src = "assets/33986-removebg-preview (1).png";

const asteroidImg = new Image();
asteroidImg.src = "assets/2e5a53a1-1dc7-4999-a943-bd0506845793-Photoroom.png";

// Player setup
const player = {
  x: canvas.width / 2 - 40,
  y: canvas.height - 120,
  width: 120,
  height: 120,
  speed: 15,
  bullets: []
};

// Asteroids
let asteroids = [];

function spawnAsteroid() {
  let x = Math.random() * (canvas.width - 60);
  asteroids.push({ x: x, y: -60, width: 100, height: 100, speed: 4 });
}

setInterval(spawnAsteroid, 1500);

// Keyboard controls
const keys = {};
document.addEventListener("keydown", (e) => {
  keys[e.code] = true;
  if (e.code === "Space") {
    player.bullets.push({
      x: player.x + player.width / 2 - 5,
      y: player.y,
      width: 10,
      height: 20,
      speed: 12
    });
  }
});
document.addEventListener("keyup", (e) => keys[e.code] = false);

function update() {
  // Move player
  if (keys["ArrowLeft"] && player.x > 0) player.x -= player.speed;
  if (keys["ArrowRight"] && player.x < canvas.width - player.width) player.x += player.speed;

  // Adjust player position if window resized
  if (player.y > canvas.height - 120) {
    player.y = canvas.height - 120;
  }

  // Move bullets
  player.bullets.forEach((bullet, i) => {
    bullet.y -= bullet.speed;
    if (bullet.y < 0) player.bullets.splice(i, 1);
  });

  // Move asteroids
  asteroids.forEach((ast, i) => {
    ast.y += ast.speed;
    if (ast.y > canvas.height) {
      asteroids.splice(i, 1);
      health -= 10; // lose health if missed
      updateHealth();
    }
  });

  // Collision detection
  player.bullets.forEach((bullet, bIndex) => {
    asteroids.forEach((ast, aIndex) => {
      if (
        bullet.x < ast.x + ast.width &&
        bullet.x + bullet.width > ast.x &&
        bullet.y < ast.y + ast.height &&
        bullet.y + bullet.height > ast.y
      ) {
        // Destroy asteroid
        asteroids.splice(aIndex, 1);
        player.bullets.splice(bIndex, 1);
        score++;
        document.getElementById("scoreboard").innerText = "Score: " + score;
      }
    });
  });
}

function updateHealth() {
  document.getElementById("health").style.width = health + "%";
  if (health <= 0) {
    alert("Game Over! Final Score: " + score);
    document.location.reload();
  }
}

function draw() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);

  // Draw player
  ctx.drawImage(aircraftImg, player.x, player.y, player.width, player.height);

  // Draw bullets
  ctx.fillStyle = "yellow";
  player.bullets.forEach(bullet => {
    ctx.fillRect(bullet.x, bullet.y, bullet.width, bullet.height);
  });

  // Draw asteroids
  asteroids.forEach(ast => {
    ctx.drawImage(asteroidImg, ast.x, ast.y, ast.width, ast.height);
  });
}

function gameLoop() {
  update();
  draw();
  requestAnimationFrame(gameLoop);
}

gameLoop();
